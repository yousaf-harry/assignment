/*DEFINE GLOBAL VARIABLE FOR MAP*/
var map_;
var api_url = 'http://localhost:8000/';

/*ON PAGE LOAD CALL INIT TO DRAW POLYGON/GEOFENCES AND VEHICLES*/
init();

function init(){
    /*CALL LUMEN API TO GET ALL GEOFENCES*/
    getGeofences();

    /*CALL LUMEN API TO CAL ALL VEHICLES LOCATION*/
    getVehicles();
}

function call_t(){
    setTimeout(function(){
        alert("Hello");
    },3000);
}

/*API CALL TO GET GEOFENCES*/
function getGeofences(){
    var url = api_url+"geofences";
    $fields = {};

    $.get(url, $fields, function(res){
        if(res.Status ==  200){
            var data =  res.data;
            for(var i=0; i<data.length; i++){
                //call function to draw polygons on map
                drawPolygon(data[i].boundry, data[i].color);
            }
        }
   },'json');
}

/*API CALL TO GET VEHICLES CURRENT LOCATIONS*/
function getVehicles(){
    var url = api_url+"vehicles";
    $fields = {};

    $.get(url, $fields, function(res){
        if(res.Status ==  200){
            var data =  res.data;
            for(var i=0; i<data.length; i++){
                //call function to update vehicle location on map
                drawPoint(data[i].location, i);
            }
        }
   },'json');
}

/*CALL GOOGLE MAP FUNCTION TO DRAW MAP*/
function initMap() {

    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 15, //map zoom level can be alter
        center: { lat: 51.51437756166311, lng: -0.08633905449802137}, //map center view location
    });
    map_ = map;
}

/*DRAW GEOFENCES ON GOOGLE MAP*/
function drawPolygon(polygone, color){

    /*modify geofences response geometry to draw on map into obj*/
    var res = polygone.replace("POLYGON((", "");
    var againReplace = res.replace("))", "");
    var temp = new Array();

   // This will return an array with strings "1", "2", etc.
    temp = againReplace.split(",");

    /*this logic to make all lat, lng into one object, to draw on map*/
    var newArray = [];
    for(var i=0; i<temp.length; i++){
        var object = temp[i].split(" ");
        newArray.push({lat: parseFloat(object[0]), lng: parseFloat(object[1])})
    }

    /*google map function to draw geofence on map */
    const bermudaTriangle = new google.maps.Polygon({
        paths: newArray,
        strokeColor: "#FF0000",
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: color,
        fillOpacity: 0.12
    });

    /*add geofence on map object*/
    bermudaTriangle.setMap(map_);
}

/*DRAW VEHICLES LOCATIONS ON GOOGLE MAP */
function drawPoint(point, id){
    /*modify vehicle location response*/
    var res = point.replace("POINT(", "");
    var resAgain = res.replace(")", "");
    var splitPoint = resAgain.split(" ");

    /*to identify vehicles by different markers on map*/
    var markers = [
        "img/red.png",
        "img/blue.png",
        "img/black.png",
        "img/green.png"
    ];


    /*initiate marker(vehicle) and set its attributes*/
    var image = markers[id];
    var beachMarker = new google.maps.Marker({
        //position: { lat: -33.89, lng: 151.274 },
        position: { lat: parseFloat(splitPoint[0]), lng: parseFloat(splitPoint[1]) },
        map_,
        icon: image
    });

    /*add vehicle as marker on map object*/
    beachMarker.setMap(map_);
}
