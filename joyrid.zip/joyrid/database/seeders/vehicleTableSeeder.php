<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Faker\Factory as Faker;

class vehicleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();

        for($i=0; $i<5; $i++) {
            DB::table('vehicles')->insert([
                'email' => $faker->firstName() . '@gmail.com',
                'location' => 'POINT(8.190586853 45.464518970)',
                'geofences_id' => $faker->randomDigit(3,5),
                'created_at' => $faker->dateTime(),
                'updated_at' => $faker->dateTime(),
            ]);
        }

    }
}
