<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Geofence;

class GeofenceController extends Controller
{

    /*GET GEOFENCES LIST*/
    function getGeofences(){
        $data = Geofence::all();
        $response = ['Status'=> 200, 'data'=>$data];
        return $response;
    }
}
