<?php

namespace App\Http\Controllers;
use Illuminate\Database\Schema\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use App\Models\Vehicle;
use App\Models\Vehicle_location;
use App\Models\Geofence;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;

class VehicleController extends Controller
{

    //Save Vehicle
    public function addVehicle(Request $request){
        $data = $request->input();

        /*VALIDATING RULE*/
        $rules = array('email' => 'unique:vehicles,email');
        $validator = Validator::make($data, $rules);

        /*EXCEPTION HANDLING*/
        if ($validator->fails()) {
            $this->throwValidationException($request, $validator);
        }

        /*SAVE VEHICLE INTO DB IF VALIDATION PASSED*/
        $vehicle = new Vehicle;
        $email = $request->input('email');
        $vehicle->email = $email;
        $vehicle->geofences_id = $request->input('geofence_id');
        $vehicle->location = DB::raw("(GeomFromText('POINT(".$request->input('lat')." ".$request->input('lng').")'))");
        $vehicle->save();

        return new JsonResponse(
            ['data' => $data],
            JsonResponse::HTTP_OK
        );
    }

    /*GET VEHICLE LIST*/
    function getVehicles(){
        $data = Vehicle::all(['id', 'email', 'geofences_id', 'location']);
        $response = ['Status'=> 200, 'data'=>$data];
        return $response;
    }

    /*CHECK VEHICLE LOCATION AND UPDATE CURRENT LOCATION*/
    public function checkLocation(Request $request){
        $vehicle = Vehicle::find($request->input('id'));
        $geofence = $vehicle->geofence;

        /*RAW QUERY TO CHECK VEHICLE IS OUTSIDE FROM ITS BOUNDARY OR NOT*/
        $query = DB::select("select ST_Contains(PointFromText('".$geofence->boundry."'), PointFromText('POINT(".$request->input('lat')." ".$request->input('lng').")'))");

        /*CONVERT QUERY RESPONSE INTO ARRAY AND GET RESPONSE*/
        $result = array_values(get_object_vars($query[0]))[0];

        /*UPDATE VEHICLE CURRENT LOCATION*/
        $vehicle->location = DB::raw("(GeomFromText('POINT(".$request->input('lat')." ".$request->input('lng').")'))");
        $vehicle->save();
        if(!$result){
            //SEND NOTIFICATION IF VEHICLE IS OUT OF OWN BOUNDARY
            $this->sendEmail($vehicle->email, 'Your vehicle is out of boundary');
            return new JsonResponse(
                [
                    'message' => 'Vehicle is out of boundary',
                    'status' => false
                ]
            );
        }

        return new JsonResponse(
            [
                'message' => 'Vehicle is inside of boundary',
                'status' => true
            ]
        );

    }

    protected function sendEmail($to_email, $msg){

        $data = array('name'=>"Person Name");

        /*send notification email*/
        /*
        Mail::send(['text'=>'mail'], $data, function($message) use($to_email, $msg) {
          $message->to($to_email, 'Joyrid Notification')->subject('Your Vehicles is out of boundary');
          $message->from('joyride@gmail.com','Joyrid Support');
        });
        echo "Basic Email Sent. Check your inbox.";
        */


    }


}
