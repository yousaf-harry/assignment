<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vehicle_location extends Model
{
    //
}
